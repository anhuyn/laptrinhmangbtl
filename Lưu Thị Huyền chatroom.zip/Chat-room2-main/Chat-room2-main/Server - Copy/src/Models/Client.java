package Models;
// Luu Minh Huyen 1502
public abstract class Client {
    public static int currentID = 0;
    // Luu Minh Huyen 1502
    public int idClient;
    public String nameClient;
    // Luu Minh Huyen 1502
    public Room room;
}
